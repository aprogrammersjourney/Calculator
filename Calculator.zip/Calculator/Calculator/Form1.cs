﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;


namespace Calculator
{
    public partial class Form1 : MetroFramework.Forms.MetroForm
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }


        //clear when clicked script

        private void maskedTextBox1_Click(object sender, EventArgs e)
        {
            if (maskedTextBox1.Text == ("Number One"))
            {

                maskedTextBox1.Clear();



            }
        }

        private void maskedTextBox1_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void textBox1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == ("Number Two"))
            {

                textBox1.Clear();



            }
        }
        //



        // square root limit script
        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox1.SelectedItem == "Square Root")
            {
                maskedTextBox1.ReadOnly = false;


                textBox1.Clear();


                textBox1.ReadOnly = true;
            }

                if (comboBox1.SelectedItem == "Addition +")
                {

                maskedTextBox1.ReadOnly = false;

                    textBox1.ReadOnly = false;

                }
                if (comboBox1.SelectedItem == "Multiplication *")
                {

                maskedTextBox1.ReadOnly = false;

                    textBox1.ReadOnly = false;

                }
                if (comboBox1.SelectedItem == "Subtraction -")
                {

                maskedTextBox1.ReadOnly = false;

                    textBox1.ReadOnly = false;
                }
                if (comboBox1.SelectedItem == "Division /")
                {

                maskedTextBox1.ReadOnly = false;

                    textBox1.ReadOnly = false;
                }
                if(comboBox1.SelectedItem == "Pi")
                {

                    textBox1.Clear();


                    textBox1.ReadOnly = true;

                    maskedTextBox1.Clear();

                    maskedTextBox1.ReadOnly = true;

                 }
                    
                    
                    
                    
        }         
        //























         //rest of program
        private void button1_Click(object sender, EventArgs e)
        {
            //clear
            textBox2.Clear();




            //addition
            if (comboBox1.SelectedItem == "Addition +")
            {

               

                var first = Convert.ToInt32(maskedTextBox1.Text);
                var second = Convert.ToInt32(textBox1.Text);

                Thread.Sleep(500);

                int answer =  first + second;

                textBox2.Text = answer.ToString();

               
            }



            //multiplication
            if (comboBox1.SelectedItem == "Multiplication *")
            {

                
                var first = Convert.ToInt32(maskedTextBox1.Text);
                var second = Convert.ToInt32(textBox1.Text);

                Thread.Sleep(500);

                int answer = first * second;

                textBox2.Text = answer.ToString();

            }



            //subtraction
            if (comboBox1.SelectedItem == "Subtraction -")
            {

               

                double first = Convert.ToInt32(maskedTextBox1.Text);
                double second = Convert.ToInt32(textBox1.Text);

                Thread.Sleep(500);

                double  answer = first - second;

                textBox2.Text = answer.ToString();

                
            }




            //division
            if (comboBox1.SelectedItem == "Division /")
            {

                

                decimal first = Convert.ToInt32(maskedTextBox1.Text);
                decimal second = Convert.ToInt32(textBox1.Text);

                Thread.Sleep(500);

                decimal answer = first / second;

                textBox2.Text = answer.ToString();

               

            }


            //square root

                if (comboBox1.SelectedItem == "Square Root")
                {

                
                double first = Convert.ToInt32(maskedTextBox1.Text);
                

                var ans1 = Math.Sqrt(first);
               

                textBox2.Text = (ans1).ToString();

                


              


                }

            //pi
            if (comboBox1.SelectedItem == "Pi")
            {


                textBox2.Text = "3.14159265359";



            }

            

                

                
            }

        }
    }
//s

