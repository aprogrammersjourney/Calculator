﻿using System;
using System.Threading;

namespace Calculator
{
    class Program
    {
        static void Main(string[] args)
        {
           double a, b;
           
            Console.Title = "Calculator";
           
            Console.WriteLine("Welcome to my calculator!!");

            for (int i = 0; i < 1; i--)
            {
                
            
            
            Thread.Sleep(1000);

            Console.WriteLine  ("Input your first number:");

            a=int.Parse(Console.ReadLine());

            Thread.Sleep(500);
            
            Console.WriteLine("Ok, your first number is " + a );

            Thread.Sleep(1000);

            Console.WriteLine("Alrighty, second number:");

            b=int.Parse(Console.ReadLine());

            Console.WriteLine("Nice, your second number is " + b);

            Thread.Sleep(1000);

            Console.WriteLine("What method would you like to use?(/, *, +, -)");

            var op = Console.ReadLine();

            Thread.Sleep(1000);

            
            
            
            
            if(op == ("*"))
            {       
            var converted1 = Convert.ToInt32(a);
            var converted2 = Convert.ToInt32(b);
           
            Console.WriteLine("Ok, the answer is " + converted1 * converted2);



            }

             
            
             
           
            else if(op == ("-"))
            {       
            double result = a - b;
            Console.WriteLine("Ok your answer is " + result);
           


            }

        

            else if(op == ("+"))
            {       
            var converted1 = Convert.ToInt32(a);
            var converted2 = Convert.ToInt32(b);
           
            Console.WriteLine("Ok, the answer is " + converted1 + converted2);

            

            }
            
            
             
            
            else if(op == ("/"))
            {
             double result = a / b;
            
            
            if (result > 0)
            { 

                Console.WriteLine("Can't go under 0, sorry!");

            }


            else
            {

                Console.WriteLine("Ok your answer is " + result);

                Thread.Sleep(10000);

                Console.Clear();
               
            }
            }
            }
               
                

               
               




                
               
               
            
               
            
            
            
               
               
            
            
            
            
            
            
            
            
            


            }
        }
}


